$(document).ready(function() {

    // Comment
    $('.comment').on('click', function() {
        $('.comment').removeClass('active');
        $(this).addClass('active');
    });

});